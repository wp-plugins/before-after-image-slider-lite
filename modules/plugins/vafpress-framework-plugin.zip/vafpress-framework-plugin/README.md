Vafpress Framework Plugin
=========================

Plugin version of Vafpress Framework (https://github.com/vafour/vafpress-framework)
